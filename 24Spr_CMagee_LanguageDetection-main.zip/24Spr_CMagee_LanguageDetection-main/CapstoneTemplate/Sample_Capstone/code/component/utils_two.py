# -*- coding: utf-8 -*-
"""
Author: Your Name
Date: 2023-11-18
Version: 1.0
"""


def func(a: object) -> object:
    """
    :rtype: object

    """
    return a


def func1(b: object) -> object:
    """
    :rtype: object

    """
    return b
