## Instruction for code folder

- All classes and functions need to be in component folder
- Main loop code needs to be in the main loop code folder.
- All codes need to have docstrings and hints.
- Give references if you copied and pasted codes from somewhere. At least put the referencing url as comments.