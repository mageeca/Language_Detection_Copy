## Instruction for demo code (OPTIONAL)

- The streamlit or any UI app needs to be here in this folder.