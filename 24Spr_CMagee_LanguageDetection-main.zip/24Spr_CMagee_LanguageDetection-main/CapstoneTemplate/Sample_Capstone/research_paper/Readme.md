## Instruction for research paper (OPTIONAL)

- If you are submitting to any journal and conference you need to use their templates.
- 
