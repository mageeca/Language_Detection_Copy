# George Washington University Data Science Program
## Capstone Course GitHub Repo template

This is based from Prof Amir Jafari's Capstone template (2024-01-01)  
https://github.com/amir-jafari/Capstone 

Modified for E. Lo's sections
